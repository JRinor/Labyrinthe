import vues.VueFenetre;

public class Main {

    public static void main(String[] args) {
        new VueFenetre();
    }
}
